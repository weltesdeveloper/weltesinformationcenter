<?php 
// Saya membantu mempatch website anda :) From Unkn0wn_H4ck3r5
header("Location: ../../index.php");
?>